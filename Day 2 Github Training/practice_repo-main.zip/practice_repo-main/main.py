def main():
    print("Hello, CCC students!")

if __name__ == "__main__":
    main()